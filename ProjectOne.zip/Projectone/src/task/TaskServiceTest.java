package task;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    void testAddTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("123", "TestName", "TestDescription");

        service.addTask(task);

        assertEquals("TestName", service.getTask("123").getName());
        assertEquals("TestDescription", service.getTask("123").getDescription());
    }

    @Test
    void testAddTaskDuplicateID() {
        TaskService service = new TaskService();
        Task task1 = new Task("123", "Name1", "Desc1");
        Task task2 = new Task("123", "Name2", "Desc2");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    @Test
    void testDeleteTaskSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Name", "Desc");

        service.addTask(task);
        service.deleteTask("123");

        assertNull(service.getTask("123"));
    }

    @Test
    void testDeleteTaskNotFound() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    @Test
    void testUpdateTaskNameSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("123", "OldName", "Desc");

        service.addTask(task);
        service.updateTask("123", "NewName", "Desc");

        assertEquals("NewName", service.getTask("123").getName());
    }

    @Test
    void testUpdateTaskDescriptionSuccess() {
        TaskService service = new TaskService();
        Task task = new Task("123", "Name", "OldDesc");

        service.addTask(task);
        service.updateTask("123", "Name", "NewDesc");

        assertEquals("NewDesc", service.getTask("123").getDescription());
    }

    @Test
    void testUpdateTaskNotFound() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("999", "Name", "Desc");
        });
    }
}
