package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date future = new Date(System.currentTimeMillis() + 10000);
        Appointment appt = new Appointment("12345", future, "Dentist");
        assertEquals("12345", appt.getAppointmentId());
        assertEquals(future, appt.getAppointmentDate());
        assertEquals("Dentist", appt.getDescription());
    }

    private void assertEquals(Date future, Date appointmentDate) {
		// TODO Auto-generated method stub
		
	}

	private void assertEquals(String string, String string2) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testInvalidId() {
        Date future = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, future, "Test");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", future, "Test");
        });
    }

    @Test
    public void testInvalidDate() {
        Date past = new Date(System.currentTimeMillis() - 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", past, "Test");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Test");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date future = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", future, null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", future, "A".repeat(51));
        });
    }
}
