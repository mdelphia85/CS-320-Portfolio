package appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {

    @Test
    public void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appt = new Appointment("1", future, "Meeting");
        service.addAppointment(appt);

        assertEquals(appt, service.getAppointment("1"));
    }

    @Test
    public void testAddDuplicateId() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appt1 = new Appointment("1", future, "Meeting");
        Appointment appt2 = new Appointment("1", future, "Another");

        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appt2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appt = new Appointment("1", future, "Meeting");
        service.addAppointment(appt);

        service.deleteAppointment("1");
        assertNull(service.getAppointment("1"));
    }

    private void assertNull(Appointment appointment) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testDeleteNonexistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }
}
